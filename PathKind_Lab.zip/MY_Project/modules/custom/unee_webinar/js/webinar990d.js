/* jQuery(document).ready(function($) {
		 var concatID ="";
		 $('#uneelight .item').each(function(){
			concatID = concatID +",#"+$(this).find(".gallery").attr("id")
		});
		concatID = concatID.substring(1, concatID.length);
		//alert(concatID);
            //$('#image-gallery, #image-gallery1').lightSlider({
            $(concatID).lightSlider({
                gallery:true,
                item:1,
				thumbItem:9,
                slideMargin: 0,
                speed:1000,
                auto:true,
                loop:true,
				pager: false,
				pauseOnHover: true,
                onSliderLoad: function() {
                    $(concatID).removeClass('cS-hidden');
                }  
            });
			
			
			//Webinar top detail page
		 var concatID1 ="";
		 $('#uneelight1 .item,#uneelight2 .item').each(function(){
			concatID1 = concatID1 +",#"+$(this).find(".gallery").attr("id")
		});
		concatID1 = concatID1.substring(1, concatID1.length);
		//alert(concatID);
            //$('#image-gallery, #image-gallery1').lightSlider({
            $(concatID1).lightSlider({
                gallery:true,
                item:1,
				thumbItem:9,
                slideMargin: 0,
                speed:1000,
                auto:false,
                loop:true,
				pager: false,
				pauseOnHover: true,
                onSliderLoad: function() {
                    $(concatID1).removeClass('cS-hidden');
                }  
            });	
			
		}); */
		
var concatID ="";
var concatID1 ="";
jQuery(document).ready(function($) {
		 
		 $('#uneelight .item').each(function(){
			concatID = concatID +",#"+$(this).find(".gallery").attr("id")
		});
		concatID = concatID.substring(1, concatID.length);
		//alert(concatID);

            //$('#image-gallery, #image-gallery1').lightSlider({
            
			
			
			//Webinar top detail page
		 
		 
});

jQuery(window).on('load',function(){
setTimeout(function(){
jQuery('#uneelight .item').each(function(){
			concatID = concatID +",#"+jQuery(this).find(".gallery").attr("id")
		});
		concatID = concatID.substring(1, concatID.length);

jQuery('#uneelight1 .item,#uneelight2 .item').each(function(){
	concatID1 = concatID1 +",#"+jQuery(this).find(".gallery").attr("id")
});
concatID1 = concatID1.substring(1, concatID1.length);
 console.log(concatID,concatID1);
},500);
/*setTimeout(function(){

},500);
 */


//alert(concatID);
	//$('#image-gallery, #image-gallery1').lightSlider({
setTimeout(function(){
jQuery(concatID).lightSlider({
                gallery:true,
                item:1,
				thumbItem:9,
                slideMargin: 0,
                speed:1000,
                auto:true,
                loop:true,
				pager: false,
				pauseOnHover: true,
                onSliderLoad: function() {
                    jQuery(concatID).removeClass('cS-hidden');
                }  
            });

	jQuery(concatID1).lightSlider({
		gallery:true,
		item:1,
		thumbItem:9,
		slideMargin: 0,
		speed:1000,
		auto:false,
		loop:true,
		pager: false,
		pauseOnHover: true,
		onSliderLoad: function() {
			jQuery(concatID1).removeClass('cS-hidden');
		}  
	});	
},1000); 
	

});