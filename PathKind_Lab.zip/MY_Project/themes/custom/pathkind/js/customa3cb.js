var lpath='/';
/* if(drupalSettings.path.baseUrl=='/'){
	lpath = '/';
}else{
	lpath = drupalSettings.path.baseUrl;
} */
jQuery(document).ready(function()  {
	
	var cityValue = jQuery('.webform-submission-health-checkups-sp-node-1450-add-form input[name="test_city_new"]').val();

jQuery('.webform-submission-health-checkups-sp-node-1450-add-form input[name="address"]').val(cityValue);

jQuery('.webform-submission-health-checkups-sp-node-1450-add-form input[name="test_city_new"]').on('change', function(){
var cityValue = jQuery(this).val();
jQuery('.webform-submission-health-checkups-sp-node-1450-add-form input[name="address"]').val(cityValue);
});

jQuery('.webform-submission-health-checkups-sp-node-1450-add-form input[name="address"]').css("display", "none");

var cityValue1 = jQuery('.webform-submission-health-checkup-node-291-add-form input[name="test_city_new"]').val();

jQuery('.webform-submission-health-checkup-node-291-add-form input[name="address"]').val(cityValue1);

jQuery('.webform-submission-health-checkup-node-291-add-form input[name="test_city_new"]').on('change', function(){
var cityValue1 = jQuery(this).val();
jQuery('.webform-submission-health-checkup-node-291-add-form input[name="address"]').val(cityValue1);
});

jQuery('.webform-submission-health-checkup-node-291-add-form input[name="address"]').css("display", "none");
   
var classNames = [];
if (navigator.userAgent.match(/(iPad|iPhone|iPod)/i)) classNames.push('device-ios');
if (navigator.userAgent.match(/android/i)) classNames.push('device-android');

var html = document.getElementsByTagName('html')[0];

if (classNames.length) classNames.push('on-device');
if (html.classList) html.classList.add.apply(html.classList, classNames);


if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
  window.document.addEventListener('touchmove', e => {
    if(e.scale !== 1) {
      e.preventDefault();
    }
  }, {passive: false});
}

});
var latitude='';  
var longitude='';

pcity="Gurugram";
/* jQuery("#edit-city-name").val(pcity);
jQuery("#edit-city-n").val(pcity);
jQuery("#edit-test-city-new").val(pcity); */

Drupal.behaviors.uploadPresc = {
    attach: function(context, settings) {
		setTimeout(function(){
			jQuery(".upload-city").val(pcity);
			jQuery(".apply-city").val(pcity);
		},1000);
		
	}
}
/* latitude='28.4595';
longitude='77.0266'; */



function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    var position = {
        coords: {latitude: 28.4028969, longitude: 76.9694737}
    };
    showPosition(position);
  }
}
function showPosition(position) {
  
	setBrowserLocation(position.coords.latitude, position.coords.longitude);
}

function setBrowserLocation(latitude, longitude) {
    jQuery.ajax({
        url: "https://www.pathkindlabs.com/pathkind_app/labs/labs_public/set_browser_location",
        method: "GET",
        data: {latitude:latitude, longitude:longitude},
        success: function(res) {
            res = JSON.parse(res);
            /* $("#search-bar").val(res.current_city_name);
            $("#city-holder").val(res.current_city_id); */
			pcity = res.current_city_name;
			/* if(pcity =='' || pcity== null){
				//console.log('new delhi');
				pcity = 'Gurugram';
			} */
			jQuery("#edit-city-name").val(pcity);
			jQuery("#edit-city-n").val(pcity);
			jQuery("#edit-test-city-new").val(pcity);
			
			jQuery.ajax({
				url: lpath + 'rest/set-loc-api?loc='+pcity,
				// url: '/rest/set-loc-api?loc='+str_city,
				success: function(){  
				},
			});
            //console.log(res);
        }   
    });
}

(function($){
	
	var nloc='';
	//console.log(lpath + 'rest/get-loc-api');
	$.ajax({
			url: lpath + 'rest/get-loc-api',
			// url: '/rest/get-loc-api',
			success: function(res){
				//console.log(res[0].title,10);
				//if(res[0].title){
					str_city = res[0].title;
					if(str_city =='' || str_city== null){
						console.log('new delhi tetsing');
						getLocation();
					}else{
						console.log(res[0].title,'here');
						pcity=res[0].title;
						jQuery("#edit-city-name").val(pcity);
						jQuery("#edit-city-n").val(pcity);
						jQuery("#edit-test-city-new").val(pcity);
					}
				}
			});
	
			

 var str_city = ''; 
	/* if(!latitude){
		location.reload();
	} */
Drupal.behaviors.setDefaultModule = {
    attach: function(context, settings) {
		
		 
		$('.form-actions .webform-button--next').css('display','block');
		$('.ui-dialog-buttonpane .webform-button--next').css('display','none');

	}
};
}(jQuery));


(function ($) {

  'use strict';

  Drupal.behaviors.mycustomtheme = {
    attach: function (context, settings) {
      $('#superfish-mobile-main-menu-toggle').click(function() {
		 // alert(9);
        if ($('#superfish-mobile-main-menu-accordion').hasClass('sf-expanded')) {
         // console.log(133);
		  $('#mobile-main-menu-menu-link-content1a29b65c-2e68-4e94-a3eb-258545a8d0ce-accordion a').text($('.m-user-name').text());
        }
      });
    }
  };
})(jQuery);

(function($){
	
	
}(jQuery));


jQuery(window).on("load", function () {
	jQuery('.page-node-291 .region-health-packages-section #block-popularhealthpackageblock a.pkg-addtocart').html('Book Now');
	
	
	if(jQuery('#desktop-v').length){ jQuery('#desktop-v').attr('tabindex',-1); jQuery('#desktop-v').focus(); }
		if(jQuery('#mobile-v').length){jQuery('#mobile-v').attr('tabindex',-1);  jQuery('#mobile-v').focus(); }
	
	if(jQuery('#edit-field-help-us-improve-wrapper').length){
		jQuery('#edit-field-help-us-improve-wrapper').attr('tabindex',0);
		jQuery('#edit-field-help-us-improve-wrapper').focus();
	}
  
  
});