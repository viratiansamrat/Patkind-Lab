//var pathkind_app_url='http://192.168.2.41/pathkind_app';
var pathkind_app_url='';
//jQuery(document).ready(function() {
	// pathkind_app_url = drupalSettings.app_urln;
	pathkind_app_url = 'https://www.pathkindlabs.com/pathkind_app';
	 //console.log('nnn',pathkind_app_url);
//});
var lpath='/';
var pkg_lsug = '';
/* if(drupalSettings.path.baseUrl=='/'){
	lpath = '/';
}else{
	lpath = drupalSettings.path.baseUrl;
} */
jQuery(document).ready(function(){
		jQuery('#demopage').click(function(){
			console.log(1);
			gtag_report_conversion('https://www.pathkindlabs.com/thank-you'); 
		});
});
var sele_val_city='';
jQuery(document).ready(function() {
	
/* new agency(Ashish) Pixel code start-27Jan22*/
if(window.location.href.indexOf("/thank-you") > -1){ //condition for only thank you page 
    
		var utm = GetParameterValues('utm');  
		var sid = GetParameterValues('sid');  
		
		if(typeof(utm) != "undefined" ) {
			if(utm == "BigTrunk" ){ 
	jQuery("body").prepend('<img src="https://bigtrunk.o18.click/p?o=17289656&m=3476&t=i" width="0px" height="0px">');
	
			}
			if(utm == "VL" || utm == "Google_VL" || utm == "Facebook_VL" ){ 
			/* commented by Asheesh ji 11 March 22*/
			/* jQuery("body").append('<iframe src="https://tracking.salesleaf.com/aff_l?offer_id=2698&adv_sub='+sid+'" scrolling="no" frameborder="0" width="1" height="1"></iframe>');*/
			}
			if(utm == "icubeswire" ){ 
			 jQuery("body").append('<iframe src="https://tracking.icubeswire.co/aff_a?offer_id=2755&adv_sub1='+sid+'&adv_sub2=" width="1" height="1" id="pixelcodeurl" /></iframe>');
			}
			if(utm == "VentesAvenues" ){ 
	jQuery("body").append('<img src="https://ventes40.gotrackier.com/pixel?adid=6220ad66cbac98055a06b403&txn_id='+sid+'">');
			}
			
			
		}
		function GetParameterValues(param) {  
            var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');  
            for (var i = 0; i < url.length; i++) {  
                var urlparam = url[i].split('=');  
                if (urlparam[0] == param) {  
                    return urlparam[1];  
                }  
            }  
        }  
	}//end check thank you page
/*new agency Pixel code end */

	   
	// Sticky header script 
    jQuery(function() {
    
    var header = jQuery(".main-top-header");
       jQuery(window).scroll(function() {
            var scroll = jQuery(window).scrollTop();
            if (scroll >= 200) {
                header.addClass("sticky");
            } else {
                header.removeClass("sticky");
            }
        });
    });
	
	/* //left menu add "active class"
	var right_tid = jQuery(".active-tid").first().text();
	jQuery(".left-page-menu").each(function(){
		if(jQuery(this).attr("id") == right_tid){
			jQuery(this).addClass("active-menu");
		}
	}); */
	
});

// Share Your Feedback Form Mobile No. Length
jQuery(document).ready(function() {

	jQuery(".node-feedback-form #edit-field-mobile-number-0-value").attr("maxlength", 10);
});



(function($){
	
	$('.path-faq #block-innerbanner').css('display','none');
	
	$('.page-term-video_album_category #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-video_album_category #block-pathkind-page-title .page-title').text('Videos');
	
	$('.page-term-blog_category #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('.page-term-blog_category #block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-blog_category #block-pathkind-page-title .page-title').text('Blog');
	
	
	$('.page-term-faq_category #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-faq_category #block-pathkind-page-title .page-title').text('Frequently Asked Question');
	
	$('.page-term-events_category #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-events_category #block-pathkind-page-title .page-title').text('Events');
	
	$('.page-term-downloads_form #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-downloads_form #block-pathkind-page-title .page-title').text('Download Forms');
	
	$('.page-term-scientific_literature_category #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-scientific_literature_category #block-pathkind-page-title .page-title').text('Scientific Literature');
	
	$('.page-term-pr_media_category #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-pr_media_category #block-pathkind-page-title .page-title').text('PR Media');
	
	$('.page-term-offers_and_announcements #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-offers_and_announcements #block-pathkind-page-title .page-title').text('Offers & Announcements');
	
	$('.page-term-research_and_development_categor #cmf-site-full-content .region.region-content').prepend('<h2 class="title-page">'+$('#block-pathkind-page-title .page-title').text()+'</h2>');
	$('.page-term-research_and_development_categor #block-pathkind-page-title .page-title').text('Research and Development');
	
	 var path = window.location.pathname;
	
	 $('.page-term-blog_category .view-id-blog_category.view-display-id-block_1 ul li a').each(function(){
		 var npath=$(this).href;
		 
		if($(this).href==path){
			$(this).addClass('active');
		}else{
			$(this).removeClass('active');
		}
	 });
}(jQuery));

//copy-paste functionality in offers-and-announcements page
jQuery('.copy_text').click(function (e) {
  var copyText = jQuery(this).attr('id');
   jQuery( '<span class="copied_message">Copied</span>' ).insertAfter(this);

   document.addEventListener('copy', function(e) {
      e.clipboardData.setData('text/plain', copyText);
      e.preventDefault();
   }, true);
	
   document.execCommand('copy'); 
   jQuery(this).closest(".field-content").find('.copied_message').html('Copied');
   setTimeout(function(){   
   jQuery('.copied_message').remove()}, 1000);
   
 });
 //share you feedback page label change accordingly
jQuery(document).ready(function() { 
		var click_result= "Excellent";
		jQuery('.field--name-field-overall-feedback .fivestar-widget div').click(function () {
			jQuery(".start-label").hide();
			jQuery(".click-result").remove();
			var anchor_href = jQuery(this).find('a').attr("href");
			var anchor_href_id = anchor_href.replace('#', '');
			jQuery("#"+anchor_href_id).show();
			if(anchor_href_id == 20){
				click_result= "Terrible";
			}else if(anchor_href_id == 40){
				click_result= "Bad";
			}else if(anchor_href_id == 60){
				click_result= "Ok";
			}else if(anchor_href_id == 80){
				click_result= "Good";
			}else{
				click_result= "Excellent";	
			}
				
				
			jQuery(this).closest(".fivestar-widget").append('<div class="click-result">'+click_result+'</div>');
		});
	
	//checkbox click add class in feedback page	
	jQuery('#edit-field-what-did-you-like-the-most .option').click(function () {
		if(jQuery(this).closest("div").find('input[class="form-checkbox"]').is(':checked')){
			jQuery(this).closest("div").removeClass("active-label");
		}else{
			jQuery(this).closest("div").addClass("active-label");
		}
	});
	
	
	
});

function highlight(string, phrase) {

	//if(config.get("highlightPhrase") && phrase !== "") {
		return highlightPhrase(string, phrase);	
	/* } else {
		return string;
	} */
		
}

function escapeRegExp(str) {
	return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function highlightPhrase(string, phrase) {
	var escapedPhrase = escapeRegExp(phrase);
	return (string + "").replace(new RegExp("(" + escapedPhrase + ")", "gi") , "<b>$1</b>");
}

function resentOtp(){ 
jQuery("#resend-otp").css({"pointer-events":"none", "cursor":"default"});  
	var timeLeft = 60;
		var elem = document.getElementById('timer');
		
		var timerId = setInterval(countdownn, 1000);
		
		function countdownn() {
		  if (timeLeft == -1) {
			clearInterval(timerId);
			jQuery("#resend-otp").removeAttr('style');
		  } else {
			if(elem != null){  
			elem.innerHTML = timeLeft;
			timeLeft--;
			}
		  }
		}		
	 }
	 
(function($){
	resentOtp();
  Drupal.behaviors.exampleModule = {
    attach: function(context, settings) { //alert(43543);
	
	var mob_sel = '.form-item-otp1 .form-text'; 
		
		
		if (window.matchMedia("(max-width: 767px)").matches)
        {
            
            jQuery(mob_sel).on('input',function(e){
				
				str = jQuery(this).val();
				str1 = str.substr(str.length-1).toLowerCase();
chArr=['1','2','3','4','5','6','7','8','9','0']; 
				if(jQuery.inArray(str1,chArr)===-1 ){
					str = str.substr(0,str.length-1);
					(jQuery(this).val(str));
				}
				// console.log(str);
			});
        }else{
				jQuery(mob_sel).keydown(function(e){
				keycode=e.keyCode;
				
				if(e.shiftKey && (e.which>=48 && e.which<=57) ){			
					return false;
				}		
				// alert(checkNumeric(keycode));
				return checkNumeric(keycode);
			}); 
		}
		
	$('.webform-submission-login-form-add-form .js-webform-input-mask').val('');
	$('.webform-submission-upload-prescription-add-form .js-webform-input-mask').val('');
	$('.webform-submission-franchising-opportunities-taxonomy_term-78-add-form .js-webform-input-mask').val('');
	$('.webform-submission-franchising-opportunities-taxonomy_term-79-form .js-webform-input-mask').val('');
	$('.webform-submission-franchising-opportunities-taxonomy_term-80-form .js-webform-input-mask').val('');
	$('.webform-submission-franchising-opportunities-taxonomy_term-81-form .js-webform-input-mask').val('');
	$('.webform-submission-apply-for-job-add-form .js-webform-input-mask').val('');
	$('.webform-submission-health-checkup-node-291-add-form .custom-otp-options').val('');
	$('#webform-submission-schedule-a-home-collection-node-20-add-form .js-webform-input-mask').val('');
	$('#webform-submission-schedule-a-home-collection-add-form .js-webform-input-mask').val('');
	$('#edit-mobile-no-').val(''); 
	$('.form-item-mobile-no .form-tel').val(''); 
	$('.form-item-enter-your-mobile-no-an-otp-will-be-sent-to-this-no- .form-text').val('');  
	$('.form-item-mobile-no- .form-text').val('');
	jQuery('#webform-submission-schedule-a-home-collection-add-form').find('.submit-button-home').prop('disabled', true);	
	jQuery(document).keyup(function(event) {
		jQuery('.form-item-otp1 tbody tr').each(function(index) {
		  jQuery(this).parents('#edit-please-fill-otp').siblings('.form-actions').find('input').prop('disabled', false);
		  if(jQuery( this ).find('input').val() == ""){
			 // jQuery(this).parents('#edit-please-fill-otp').siblings('.form-actions').find('input').prop('disabled', true);
			 jQuery('#webform-submission-schedule-a-home-collection-add-form').find('.submit-button-home').prop('disabled', true);
			 
		  }
		});
		
		// jQuery('#webform-submission-schedule-a-home-collection-add-form').find('.submit-button-home').attr('onclick',"this.disabled=true;this.value='wait...';this.form.submit();");
	});
	


	
	// console.log(drupalSettings.app_urln,'cell');
		//for header health search
		$(context).find('#edit-pkg').on('keyup', function(event) {
			var test = $('#ui-id-2').html();
			setTimeout(function(){ 
			// console.log('keyup',$('#ui-id-2').html(),$('#edit-pkg').val());
				$('#ui-id-2 li').each(function(index,val){
					search  = $('#edit-pkg').val();
					newtest = highlight($(this).find('a').text(),search);
					$(this).find('a').html(newtest);	
				});					
			},1200);			
		});
		
		$(context).find('#edit-pkg').on('autocompleteselect', function(event, data) {
			
			pkg_lsug = $(this).val();
			$.each(data,function(index,val){
				test=val.value;			
				val.value=test.replace(/<b>|<\/b>?/g,'');
			})
			
			$(context).find('#edit-pkg').val('');
		});
		//for header city search
		$(context).find('#edit-city-name').on('autocompleteselect', function(event, data) {
			$.each(data,function(index,val){
				test=val.value;
				val.value=test.replace(/<b>|<\/b>?/g,'');
			})
		});
		//for home collection form
		$(context).find('#edit-city-n').on('autocompleteselect', function(event, data) {
			$.each(data,function(index,val){
				test=val.value;		
				val.value=test.replace(/<b>|<\/b>?/g,'');			
			})
		});
		//for apply for job
		$(context).find('.js-form-item-city-name .custom-city-search').on('autocompleteselect', function(event, data) {
			
			$.each(data,function(index,val){
				test=val.value;	
				val.value=test.replace(/<b>|<\/b>?/g,'');			
			})
		});
		//for upload prescription
		$(context).find('.js-form-item-city .custom-city-search').on('autocompleteselect', function(event, data) {
			$.each(data,function(index,val){
				test=val.value;
				val.value=test.replace(/<b>|<\/b>?/g,'');			
			})
		});
		//for Partner with us pages
		$(context).find('#edit-test-city-new').on('autocompleteselect', function(event, data) {
			$.each(data,function(index,val){	
				test=val.value;
				val.value=test.replace(/<b>|<\/b>?/g,'');			
			})
		});
		
	
	if(jQuery('.webform-submission-upload-prescription-add-form .messages--status').length){
		if(jQuery('.webform-submission-upload-prescription-add-form h2').text()!='Verify Mobile No.'){
			// console.log('sss');
		
			jQuery('.webform-submission-upload-prescription-add-form h2').html('Thank You');
			
			jQuery('.webform-submission-upload-prescription-add-form .form-item-top-message').html(jQuery('.webform-submission-upload-prescription-add-form .messages--status').html());
			jQuery('.webform-submission-upload-prescription-add-form .messages--status').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .form-text').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .form-email').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .form-type-webform-document-file').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .description').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .form-actions').css('display','none');
			// jQuery('.webform-submission-upload-prescription-add-form .form-item-bottom-message').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .form-item-bottom-message').html('<button type="button" class="ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close upload-prescription-close" title="Close">OK</button>');
			jQuery('.webform-submission-upload-prescription-add-form .form-item-city-name-').css('display','none');
			jQuery('.webform-submission-upload-prescription-add-form .form-item-mobile-no').css('display','none');
		}
		
		jQuery('.upload-prescription-close').click(function(){
			 $('.ui-dialog-titlebar-close').click();
		});
		
	}
	
	
	jQuery(".custom-otp-options").keyup(function (e) {
		
		if ( jQuery(this).val().length == 1) {
		  
		  jQuery(this).parents('tr').next().find(".custom-otp-options").focus();
		  
		}
		if(e.keyCode==8 ){
			jQuery(this).parents('tr').prev().find(".custom-otp-options").focus();
		}
		
	});
	
	// for city name
	jQuery('.webform-submission-upload-prescription-add-form .webform-select2').change(function(){
		var city_val=jQuery(this).find("option:selected").text();
		jQuery('input:hidden[name=city_value]').val(city_val);
	});
	
	
	jQuery('.change-mobile-no').insertAfter('.webform-submission-apply-for-job-form .description');	
	jQuery('.resend-otp').insertBefore('.webform-submission-apply-for-job-form .webform-button--submit');
    jQuery('.change-mobile-no').insertAfter('.webform-submission-upload-prescription-form .description');	
	jQuery('.resend-otp').insertBefore('.webform-submission-upload-prescription-form .webform-button--submit');
	
	//OTP Timer start code here.... 
	jQuery("#resend-otp").css({"pointer-events":"none", "cursor":"default"});
	//resentOtp();
  
	jQuery("#resend-otp").click(function(){
      // jQuery("#resend-otp").css({"pointer-events":"none", "cursor":"default"});
          resentOtp();
	});
	
	jQuery("#resend-otp-upload").click(function(){
      // jQuery("#resend-otp-upload").css({"pointer-events":"none", "cursor":"default"});
          resentOtpn('timer-upload','#resend-otp-upload');
	});
	jQuery("#resend-otp-login").click(function(){
       //jQuery("#resend-otp-login").css({"pointer-events":"none", "cursor":"default"});
          resentOtplogin('timer-login','#resend-otp-login');
	});
	
	resentOtplogin('timer-login','#resend-otp-login');
	
	resentOtpn('timer-upload','#resend-otp-upload');
	
	var otpfran =0; 
	jQuery("#resend-otp-fran").click(function(){
       // jQuery("#resend-otp-fran").css({"pointer-events":"none", "cursor":"default"});
	   otpfran =1;
          resentOtpfran('timer-fran','#resend-otp-fran');
	});
	
	setTimeout(function(){
		if( (!jQuery('#webform-submission-login-form-form-ajax').length) && (!jQuery('#webform-submission-upload-prescription-form-ajax').length) && (otpfran ==0) ){
			if(jQuery('#timer-fran').length){
				var tt = jQuery('#timer-fran').val();
				//console.log('tt',tt);
				if(tt==0){
					//console.log('hhh');
				
				}
				resentOtpfran('timer-fran','#resend-otp-fran');
			}
		}
	},1000);
		//}
		
	// }
	function resentOtpfran(sel,sel1){   
	jQuery(sel1).css({"pointer-events":"none", "cursor":"default"});
	var timeLeftfran = 60;
		var elem = document.getElementById(sel);
		
		var timerIdfran = setInterval(countdownlogin, 1000);
		function countdownlogin() {
		  if (timeLeftfran == -1) {
			clearInterval(timerIdfran);
			otpfran =0;
			jQuery(sel1).removeAttr('style');
			jQuery(sel1).removeClass('resend-otp');
		  } else {
			if(elem != null){  
			elem.innerHTML = timeLeftfran;
			timeLeftfran--;
			}
		  }
		}		
	 }
	
	function resentOtplogin(sel,sel1){   
	jQuery(sel1).css({"pointer-events":"none", "cursor":"default"});
	var timeLeftupload = 60;
	// jQuery(sel1).css({"pointer-events":"none", "cursor":"default"});
		var elem = document.getElementById(sel);
		
		var timerIdlogin = setInterval(countdownlogin, 1000);
		
		function countdownlogin() {
		  if (timeLeftupload == -1) {
			clearInterval(timerIdlogin);
			jQuery(sel1).removeAttr('style');
			jQuery(sel1).removeClass('resend-otp');
			console.log('clearInterval');
		  } else {
			  
			if(elem != null){  
			elem.innerHTML = timeLeftupload;
			timeLeftupload--;
			}
		  }
		}		
	 }
	
	resentOtpapply('timer-apply','#resend-otp-apply');
	
	function resentOtpapply(sel,sel1){   
	jQuery(sel1).css({"pointer-events":"none", "cursor":"default"});
	var timeLeftupload = 60;
		var elem = document.getElementById(sel);
		
		var timerId = setInterval(countdownupload, 1000);
		
		function countdownupload() {
		  if (timeLeftupload == -1) {
			clearInterval(timerId);
			jQuery(sel1).removeAttr('style');
			jQuery(sel1).removeClass('resend-otp');
		  } else {
			if(elem != null){  
			elem.innerHTML = timeLeftupload;
			timeLeftupload--;
			}
		  }
		}		
	 } 
	
	if(jQuery('.page-node-291').length){
	 resentOtphealthckup('timer-hckp','#resend-otp-hckp');
	 //var otpfran =0; 
		
	}
	if(jQuery('.page-node-1450').length){
	 resentOtphealthckup('timer-hckp','#resend-otp-hckp');
	 //var otpfran =0; 
		
	}
	jQuery("#resend-otp-hckp").click(function(){
	   // jQuery("#resend-otp-fran").css({"pointer-events":"none", "cursor":"default"});
	   //otpfran =1;
		  resentOtphealthckup('timer-hckp','#resend-otp-hckp');
	});
	function resentOtphealthckup(sel,sel1){  
jQuery(sel1).css({"pointer-events":"none", "cursor":"default"});	
	var timeLeftupload = 60;
		var elem = document.getElementById(sel);
		
		var timerId = setInterval(countdownupload, 1000);
		
		function countdownupload() {
		  if (timeLeftupload == -1) {
			clearInterval(timerId);
			jQuery(sel1).removeAttr('style');
			jQuery(sel1).removeClass('resend-otp');
		  } else {
			if(elem != null){  
			elem.innerHTML = timeLeftupload;
			timeLeftupload--;
			}
		  }
		}		
	 } 
	 
	function resentOtpn(sel,sel1){   
	jQuery(sel1).css({"pointer-events":"none", "cursor":"default"});
	var timeLeftupload = 60;
		var elem = document.getElementById(sel);
		
		var timerId = setInterval(countdownupload, 1000);
		
		function countdownupload() {
		  if (timeLeftupload == -1) {
			clearInterval(timerId);
			jQuery(sel1).removeAttr('style');
			jQuery(sel1).removeClass('resend-otp');
		  } else {
			if(elem != null){  
			elem.innerHTML = timeLeftupload;
			timeLeftupload--;
			}
		  }
		}		
	 }
    //resentOtp();
	
	 
	 //Select2 JS Polyfill
    if (!Element.prototype.matches) {
        Element.prototype.matches =
            Element.prototype.matchesSelector ||
            Element.prototype.mozMatchesSelector ||
            Element.prototype.msMatchesSelector ||
            Element.prototype.oMatchesSelector ||
            Element.prototype.webkitMatchesSelector ||
            function (s) {
                var matches = (this.document || this.ownerDocument).querySelectorAll(s),
                    i = matches.length;
                while (--i >= 0 && matches.item(i) !== this) { }
                return i > -1;
            };
    }
	
	jQuery('.sf-accordion-toggle a.sf-expanded').click(function(){
		console.log(1);
	});
	
	var mob_sel = '.form-item-enter-your-mobile-no-an-otp-will-be-sent-to-this-no- .form-text,#edit-mobile-no-,.form-item-mobile-no .form-tel,.form-item-mobile-no .form-text,#edit-field-mobile-number-0-value,.field--name-field-mobile-number .form-text,.form-item-mobile-no- .form-text'; 
		
		if (window.matchMedia("(max-width: 767px)").matches)
        {
            
            jQuery(mob_sel).on('input',function(e){
				
				str = jQuery(this).val();
				str1 = str.substr(str.length-1).toLowerCase();
chArr=['1','2','3','4','5','6','7','8','9','0']; 
				if(jQuery.inArray(str1,chArr)===-1 ){
					str = str.substr(0,str.length-1);
					(jQuery(this).val(str));
				}
				// console.log(str);
			});
        }else{
				jQuery(mob_sel).keydown(function(e){
				keycode=e.keyCode;
				
				if(e.shiftKey && (e.which>=48 && e.which<=57) ){			
					return false;
				}		
				// alert(checkNumeric(keycode));
				return checkNumeric(keycode);
			}); 
		}
	
	var name_sel = '#edit-name,.form-item-name .form-text,#edit-patient-name,#edit-what-is-your-name-,#edit-title-0-value,.node-feedback-form .field--name-title .form-text,.node-feedback-form .field--name-field-city .form-text';
		/* jQuery(name_sel).keydown(function(e){
			keycode=e.keyCode;          
			if(e.shiftKey && (e.which>=48 && e.which<=57) ){            
				return false;
			}
			// return checkAlphaNumeric(keycode);
			return onlyAlphabets(keycode);
		}); */
		if (window.matchMedia("(max-width: 767px)").matches)
        {
            
            jQuery(name_sel).on('input',function(e){
				
				str = jQuery(this).val();
				str1 = str.substr(str.length-1).toLowerCase();
chArr=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' '];
				if(jQuery.inArray(str1,chArr)===-1 ){
					str = str.substr(0,str.length-1);
					(jQuery(this).val(str));
				}
			});
        }else{
				jQuery(name_sel).on('keydown',function(e){
					// console.log('test');
					keycode=e.keyCode;          
					if(e.shiftKey && (e.which>=48 && e.which<=57) ){            
						return false;
					}
					
					return onlyAlphabets(keycode);
				});
		}
		
	var address_sel = '#edit-address,.js-form-item-skill .form-text,.js-form-item-current-ctc .form-text,.js-form-item-expected-ctc .form-text,.field--name-field-feedback .form-textarea';
		
		if (window.matchMedia("(max-width: 767px)").matches)
        {
            
            jQuery(address_sel).on('input',function(e){
				
				str = jQuery(this).val();
				str1 = str.substr(str.length-1).toLowerCase();
			chArr=['#','$','^','`','~',';',':',',','.','/','?','[',']','{','}','@','!','*','+','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0'];
				if(jQuery.inArray(str1,chArr)===-1 ){
					str = str.substr(0,str.length-1);
					(jQuery(this).val(str));
				}
			});
        }else{
				jQuery(address_sel).on('keydown',function(e){
					keycode=e.keyCode;          
					if(e.shiftKey && (e.which>=48 && e.which<=57) ){            
						return false;
					}
					
					// return onlyAlphabets(keycode);
					return checkAlphaNumeric(keycode);
				});
		}
		
	var email_sel = '.js-form-item-email #edit-email,.form-email,.node-feedback-form .field--name-field-email-id .form-email'; 
		
		
		if (window.matchMedia("(max-width: 767px)").matches)
        {
            
            jQuery(email_sel).on('input',function(e){
				
				str = jQuery(this).val();
				str1 = str.substr(str.length-1).toLowerCase(); 
			chArr=['@','.','_','-','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6','7','8','9','0'];
				if(jQuery.inArray(str1,chArr)===-1 ){
					str = str.substr(0,str.length-1);
					(jQuery(this).val(str));
				}
			});
        }else{
			jQuery(email_sel).keydown(function(e){
				keycode=e.keyCode;
				str1 = jQuery(this).val();
				/* if(str1.indexOf('.') != -1){
					if(keycode==190 || keycode==110){
						return false;
					}					
				} */
				
				if(e.shiftKey && (e.which>=48 && e.which<=57) ){
					if(e.which == 50 && !(str1.contains('@')) ){
						return true;
					}else{
						return false;
					}
				}		
				
				return onlyEmail(keycode);
			}); 
		}
	
	
	}
  };  
  $('#edit-pkg').keydown(function(e){
	
	  key=e.keyCode;
	
	  if(key==13){
		e.preventDefault();
		var pkgn=$('#edit-pkg').val();
		var city=$('#edit-city-name').val();
		pkg=pkgn.split(" ").join("-").toLowerCase();
		pkg = pkg.replace(/<\/?b>/g, '');
		pkg = pkg.replace(/\(|\)/g, '');
		 
var sug_name_srch = pathkind_app_url+'/api/v1/suggestions/data_type_of_search?search="'+pkgn+'"';

		$.ajax({
			url: sug_name_srch,
			
			success: function(res){
				slug= res.data.slug;
				if(res.data.type=='lab'){
					// $(location).attr('href', pathkind_app_url+'/lab-locator?lab_slug='+slug+'&city='+city);					
					$(location).attr('href', pathkind_app_url+'/find-a-pathology-lab-near-you?lab_slug='+slug+'&city='+city);					
				}else{
					// $(location).attr('href', pathkind_app_url+'/test-list?test_package_name='+slug+'&city='+city);
					$(location).attr('href', pathkind_app_url+'/book-blood-test-online-in-india?test_package_name='+slug+'&city='+city);
				}
			}
		
		});
		
	  }
	  
  });
$( "#webform-submission-header-search-form-add-form a" ).click(function(){
		var pkg=$('#edit-pkg').val();
		var city=$('#edit-city').val();
		pkg=pkg.split(" ").join("-").toLowerCase();
		 
		$(location).attr('href', pathkind_app_url+'/test-list?test_package_name='+pkg);
	  
	});
	
	
	//OPEN OVERLAY START
	$('.prf-login').on('click',function(){
		$('#plbOverlay').css('display', 'block');	
		
	});
	
	
	$('.upload').on('click',function(){
		$('#plbOverlay').css('display', 'block');
	});
	
	$('.opening-apply').on('click',function(){
		$('#plbOverlay').css('display', 'block');
	});
	
	
	
(function ($, Drupal) {

  Drupal.behaviors.sampleModalReaction = {

    attach: function(context) {

      $(window).once().on('dialog:afterclose', function(dialog, $element, settings) {

          $('#plbOverlay').css('display', 'none');//alert('function called');

        });
		
	
	/* $('#edit-actions-submit').click(function(e){
		e.preventDefault();
		console.log('hhh');
		// return true;
	});
	onclick="this.disabled=true;this.value='Sending, please wait...';this.form.submit();" */
		
	$(context).find('#edit-pkg').on('autocompleteclose', function (event, data) { 
	 
		var pkgn=$('#edit-pkg').val();
		var pkgn1=$('#edit-pkg').val();
		var city=$('#edit-city-name').val();
		
		console.log(pkgn.split("-("));
		pkgn=pkgn.split("-(")[0].trim();
// var sug_name_srch = pathkind_app_url+'/api/v1/suggestions/data_type_of_search?search='+encodeURIComponent(pkgn);
 
 sug_name_srch1 = encodeURI(pathkind_app_url+'/tests/test_public/suggestion_drupal?search='+pkg_lsug+'&loc='+city);
 
 $.ajax({
			url: sug_name_srch1,
			success: function(res){
				//console.log(JSON.parse(res).data);
				var pkg_data = JSON.parse(res).data; 
				$.each(pkg_data,function(key,val){
					
					if(val.trim() == pkgn1.trim() ){
						//console.log('here',val,'key-',key);
						slug = key;
						console.log(slug);
						pkgn = slug;
var sug_name_srch = pathkind_app_url+'/api/v1/suggestions/data_type_of_search?search='+encodeURIComponent(pkgn);

		$.ajax({
			url: sug_name_srch,
			success: function(res){
				console.log(res.data);
				if(res.data.type=='lab'){
										
					$(location).attr('href', pathkind_app_url+'/find-a-pathology-lab-near-you?lab_slug='+res.data.slug);					
				}else if(res.data.type=='test' || res.data.type=='package'){
					// $(location).attr('href', pathkind_app_url+'/test-list?test_package_name='+res.data.slug+'&city='+city);
//console.log(pathkind_app_url+'/book-blood-test-online-in-india?test_package_name='+res.data.slug+'&city='+city);
					$(location).attr('href', pathkind_app_url+'/book-blood-test-online-in-india?test_package_name='+res.data.slug+'&city='+city);
				}
			}
		
		});
					}
				});
			}
		});
		

	  
	});	
	
	var city_sel = '#edit-city-name,#edit-city-n';
	$(context).find(city_sel).on('autocompleteclose', function (event, data) { 
	 
	  console.log('here',$(this).val(),'testing');
	  
	  
	  if($(this).val()){
	  if($('span.cart-badge span').text()!=0){
	  var i= confirm('Your cart will empty if you change location,Please confirm?');
	  }
	  var city_urln= pathkind_app_url+'/api/v1/cities/exists';
	 var cc =  $(this).val();
	   $.ajax({
		   url: city_urln, 
		   type: "POST",
		   dataType: "json",
		   contentType: "application/json; charset=utf-8",
		   data: JSON.stringify({ city: cc }),
		   success: function (result) {
			   // console.log('hhh',result);
			   var city_url= pathkind_app_url+'/labs/labs_public/set_current_city?city_name='+cc;
			   console.log(city_url);
			  /* console.log(city_url);
			  return false;	  */
				$(city_sel).val(cc);
					$.ajax({
					url: city_url,
					success: function(res){
						console.log(res,'remote');
					}, 
					  
					});
					console.log(lpath + 'rest/set-loc-api?loc='+cc)
					$.ajax({
					  // url: drupalSettings.path.baseUrl+'/rest/set-loc-api?loc='+$(this).val(),
					  url: lpath + 'rest/set-loc-api?loc='+cc,
					  success: function(){
						  
					  },
					});
					if(i==true){
					  $.ajax({
						  url: pathkind_app_url+'/tests/test_public/unset_cart',
						  success: function(){
							  $.ajax({
									url: pathkind_app_url+'/cart/cart_public/cart_count_api',
									success: function(res){
										res = res.split(":");
										//console.log($.type(res),res[0],res[1].replace("}",""));
										if(res[1].replace("]","")!=0){
											$('.cart-badge span').text(res[1].replace("}",""));
											$('.cart-badge').css('display','block');
										}
									}
								});
						  },
					  })
					}
					setTimeout(function(){
					location.reload();},1000);
				//}
			},
			error: function (err) {
			
			}
		 }); // ajax call closing
	}
	//return false; 
	});	
	
	$('.search-city-wrapper,#edit-city-name').focusin(function(e){
		e.stopPropagation();
		
		sele_val_city = $(this).val();
		
		$(this).val('');
	});	
	
	$('#edit-city-name,#edit-city-name').click(function(e){
		e.stopPropagation();
		
		sele_val_city = $(this).val();
		
		$(this).val('');
	});	 
	$('#edit-city-name').blur(function(){
		
		
		if($('#edit-city-name').val()==''){
			
			if(sele_val_city==''){
				
				$.ajax({
					url: lpath + 'rest/get-loc-api',
					success: function(res){
						str_city = res[0].title;
						
						sele_val_city = str_city.charAt(0).toUpperCase()+str_city.slice(1);
						$('#edit-city-name').val(sele_val_city);
					}
				});
			}else{
				
				$('#edit-city-name').val(sele_val_city);
			}
			
		}else{
			
		}
		
	});	
	
    }
	
	
	
  };

})(jQuery, Drupal);

}(jQuery));


jQuery(window).on('load', function(){
jQuery('#main-menu-right-section-menu-link-content9757bb1d-fb91-416f-9651-aa66c44b2eba a').css('pointer-events','all' );	
jQuery('.view-id-pathkind_system.view-display-id-block_4 a').css('pointer-events','all' );	
//PACKAGE SECTION SLIDER JS
if(jQuery('#temp-health').length){
jQuery('#temp-health').flexslider({
    animation: "slide",
    animationLoop: false,
    itemWidth: 271, 
    itemMargin: 16,
	move: 1, 
	pauseOnHover:true,
  });
}

if(jQuery('#why-pathkind').length){
jQuery('#why-pathkind').flexslider({
    animation: "slide",
    animationLoop: false,
    itemWidth: 271, 
    itemMargin: 16,
	move: 1, 
	pauseOnHover:true,
  });
}

//make cart selected if pkg available on cart

jQuery.ajax({
		url: pathkind_app_url+'/cart/cart_public/cart_item_api',
		success: function(res){
			res = res.replace("]","")
			res = res.replace("[","")
			res = res.replaceAll('"',"")
			res = res.split(",");
			jQuery('#temp-health .health-buynow a').each(function(){
				
				if(jQuery.inArray(jQuery(this).attr('id'),res)>=0){

					jQuery(this).parents('li').addClass('selected');
				}
			})
		},
}); 


//left menu add "active class"
	setTimeout(function(){
		var right_tid = jQuery(".active-tid").first().text();
		jQuery(".left-page-menu").each(function(){
			if(jQuery(this).attr("id") == right_tid){
				jQuery(this).addClass("active-menu");
			}
		});
	},500);
  
});



jQuery(window).on('load',function(){
	var path = window.location.pathname;
	jQuery.urlParam = function(name){
		var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
		if (results==null) {
		   return null;
		}
		return decodeURI(results[1]) || 0;
	}
	//console.log(path);
	setTimeout(function () {
		if(path=='/' && jQuery.urlParam('app_param')=='upload_prescription'){
			
			jQuery('.upload.use-ajax').click();
		}
	},200);
});

(function($){
	if(!$('.cart-badge span').text()){
		$('.cart-badge').css('display','none');
	}
	
	
	
	$('.path-frontpage .region-health-packages-section').on('click','#block-popularhealthpackageblock a.pkg-addtocart',function(e){
		e.preventDefault();
		var itemid=$(this).attr('id');
		$(this).html('Added to cart');
		$(this).closest('li').addClass('selected');
		
		$.ajax({
			url: pathkind_app_url+'/cart/cart_public/add_item_api?item_id='+itemid+'&item_type=2',
			success: function(res){
				res = res.split(":");
				if(res[1].replace("]","")!=0){	
					$('.cart-badge span').text(res[1].replace("}",""));
					$('.cart-badge').css('display','block');
					$(this).css('pointerEvents','none');
					$(this).addClass('disabled');
					
				}
			}
		});
	});
}(jQuery));

function pkgAddtocart(elem){
	
return false;
}

(function($){
	//console.log('here');
	$.ajax({
		url: pathkind_app_url+'/cart/cart_public/cart_count_api',
		success: function(res){
			res = res.split(":");
			// console.log('m',res);
			if(res[1].replace("]","")!=0){
				$('.cart-badge span').text(res[1].replace("}",""));
				$('.cart-badge').css('display','block');
			}
		}
	});

	

}(jQuery));

(function($) {
  		AOS.init();
	}(jQuery));

//AOS.init();

(function($){
	$('#webform-submission-schedule-covid-drive-thru-test-add-form #edit-drive-thru').change(function(){
		
		var val_term=$(this).val();
		var drive_url='';
		if(drupalSettings.path.currentLanguage=='hi'){
		drive_url=drupalSettings.path.baseUrl+'hi/api-covid-drive?_format=json&field_drive_in_target_id='+val_term
		}else{
		drive_url=drupalSettings.path.baseUrl+'api-covid-drive?_format=json&field_drive_in_target_id='+val_term
		}
		
		$.ajax({
			url: drive_url,
			type:"GET",			
			contentType:"application/json; charset=utf-8",
			dataType:"json",
			success: function(res){
				$('#block-schedulecoviddrivethruaddresandmapcustomblock .field--name-body.field--type-text-with-summary').html((res[0].body));
			}
		});
	});
	
	
	
	if($('.page-term-nrl_departments_category').length){
		//nrl-cat
		var nrl_options='';
		var nrl_cat_path = window.location.pathname;
		var nrl_url=drupalSettings.path.baseUrl+'api-nrl-categories?_format=json';
		if(drupalSettings.path.currentLanguage=='hi'){
			nrl_url=drupalSettings.path.baseUrl+'hi/api-nrl-categories?_format=json';
		}
		
		$.ajax({
			url: nrl_url,
			type: "GET",
			success: function(res){
				$.each(res,function(key,value){
					$('#nrl-cat').find('option').not(':first').remove();
					var selected='';
					if(nrl_cat_path==value.view_taxonomy_term){
						selected='selected="selected"';
					}
					nrl_options += '<option value="'+value.view_taxonomy_term+'" '+selected+' >'+value.name+'</option>';
					
				});
				$('#nrl-cat').append(nrl_options);
			}
		});
	}
}(jQuery));


(function($){

$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec($('#main-menu-link-content688ff7e9-4161-48a7-a8c6-6700a2ecdd9b a').attr('href'));
    if (results==null) {
       return null;
    }
    return decodeURI(results[1]) || 0;
}

tok = $.urlParam('token');

if(tok){
	href_text = $('.view-id-pathkind_system.view-display-id-block_3 .views-field-field-image a').attr('href');
	href_text = href_text + '/?token=' + tok;
	$('.view-id-pathkind_system.view-display-id-block_3 .views-field-field-image a').attr('href',href_text);
}

}(jQuery));


jQuery(document).ready(function(){
var city = encodeURIComponent(jQuery('#edit-city-name').val());
if(jQuery(".search__labtestpackage").length){
var $elem =jQuery(".search__labtestpackage").autocomplete({
	
	source: function( request, response ) {
	// Fetch data
	var phrase = request.term;
	city = encodeURIComponent(jQuery('#edit-city-name').val());
	// url = `http://192.168.2.41/pathkind_app/tests/test_public/get_suggestions?phrase=${phrase}&format=json`;
	url = `https://www.pathkindlabs.com/pathkind_app/tests/test_public/suggestion_drupal?search=${phrase}&loc=${city}`;
	console.log(url,'c',city);

	jQuery.ajax({
	url: url,
	//type: 'post',
	dataType: "json",
	
	success: function( data ) {
	//console.log(data);
	 var j = 0;
	 var res = {};
	 var results=[] ;
	 
	 var maxlength = 500;
	 
	 jQuery.each(data.data,function(i,val){
		 
		 if(j < maxlength ){
			 var lval='';
			 
			 lval = val;
			 // console.log(lval);
			 res = {
				 label: lval,
				 value: i
			 }
			 results.push(res);
			 
			 j++;
		 }
	
	 });
	 // console.log(results); 
        response(results);
		
	}
	});
	},
  select: function (event, ui) {
	  // console.log(ui);
    
	
	
						pkgn = ui.item.value;
var sug_name_srch = pathkind_app_url+'/api/v1/suggestions/data_type_of_search?search='+encodeURIComponent(pkgn);
 
console.log(sug_name_srch);
		jQuery.ajax({
			url: sug_name_srch,
			success: function(res){
				console.log(res.data);
				if(res.data.type=='lab'){
									
					jQuery(location).attr('href', pathkind_app_url+'/find-a-pathology-lab-near-you?lab_slug='+res.data.slug);					
				}else if(res.data.type=='test' || res.data.type=='package'){
					
					jQuery(location).attr('href', pathkind_app_url+'/book-blood-test-online-in-india?test_package_name='+res.data.slug+'&city='+city);
				}
			}
		
		});
				
	
     return false;
  },
  focus: function(event, ui){
	
     return false;
   }, 
 })




// var elem = jQuery("#studentName").autocomplete({/* all your parameters*/}),
    elemAutocomplete = $elem.data("ui-autocomplete") || $elem.data("autocomplete");
if (elemAutocomplete) {
    elemAutocomplete._renderItem = function (ul, item) {
		//console.log(item);
		//if(item.value != 'city_id'){
        var newText = String(item.label).replace(
                new RegExp(this.term, "gi"),
                "<b>$&</b>");

        return jQuery("<li></li>").data("item.autocomplete", item)
            .append("<div>" + newText + "</div>")
            .appendTo(ul);
		//}
    };
}

}
	
	
});

jQuery(window).on('load',function(){
	 // jQuery('#edit-name').attr('autocomplete','nope');
	 jQuery('#edit-name').attr('autocomplete','off');
	/* jQuery('#edit-name').attr('readonly','readonly');
	jQuery('#edit-name').attr('onfocus',"this.removeAttribute('readonly');"); */
});


function checkNumeric(keycode){
	if((keycode >= 48  && keycode <= 57) || (keycode >= 96  && keycode <= 105) || keycode == 8 || keycode == 13 || keycode == 46 ||  keycode == 37 || keycode == 39 || keycode==9 ){			
		return true;
	}else{			
		return false;
	}
}

function checkAlphaNumeric(keycode){
	if((keycode >= 65  && keycode <= 90) || (keycode >= 48  && keycode <= 57) || (keycode >= 96  && keycode <= 105) || keycode == 8 || keycode == 13 || keycode == 46 ||  keycode == 37 || keycode == 39 || keycode==9 || keycode == 32){			
		return true;
	}else{			
		return false;
	}
}
function onlyAlphabets(keycode){	
	
	if((keycode >= 65  && keycode <= 90) || keycode == 8 || keycode == 13 || keycode == 46 ||  keycode == 37 || keycode == 39 || keycode == 9 || keycode==32){			
		return true;
	}else{ 
		return false;
	}
}

function onlyEmail(keycode){
	//console.log(keycode);
	if((keycode >= 65  && keycode <= 90) || (keycode >= 48  && keycode <= 57) || (keycode >= 96  && keycode <= 105) || keycode == 8 || keycode == 13 || keycode == 46 ||  keycode == 37 || keycode == 39 || keycode==9 || keycode==190 || keycode==110 ){			
		return true;
	}else{			
		return false;
	}
}